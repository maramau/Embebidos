#ifndef CRITICAL_C
#define CRITICAL_C

void critical_begin(void);
void critical_end(void);

#endif


// Este device controla los eventos del deviceX, pero no sabe que eventos
// ejecutar.

#include <Arduino.h>
#include <avr/interrupt.h>
#include "device.h"

void (*callback_fn)();

//#####################  ISR #########################################
void isr()
{
  //Evitar llamar a la rutina de "callback" desde aquí porque no sabemos que tiene esa rutina.
  //A fines practicos este ejemplo es reflejar el uso de una callback
  callback_fn(); 
  
}

//######################  Rutina API #################################

void device_init(device_cfg *config)
{
  // Configurar el PIN como entrada con resistena de PULL UP
  pinMode(config->pin, INPUT_PULLUP);
  // Guarda el evento
  callback_fn = config->callback_fn; 
  // Habilita una interrupcion cuando encuentra un cambio en el PIN=2
  attachInterrupt(digitalPinToInterrupt(config->pin), isr, CHANGE) ; 
}

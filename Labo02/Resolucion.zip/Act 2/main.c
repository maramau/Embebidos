#include <stdbool.h>
#include <stdint.h>
#include <LiquidCrystal.h>
#include <Arduino.h>
#include <avr/interrupt.h>

#include "critical.h"
#include "device.h"
#include "fnqueue.h"
// these constants won't change.  But you can change the size of
// your LCD using them:
const uint8_t numRows = 2;
const uint8_t numCols = 16;

// initialize the library with the numbers of the interface pins
LiquidCrystal lcd(8, 9, 4, 5, 6, 7);

//*
//Funciones que usara el ISR
//*
void sue_up(){
  lcd.setCursor(0,1);
  lcd.print("Suelto UP");
}
void apr_up(){
  lcd.setCursor(0,1);
  lcd.print("Apreto UP       ");
}
void sue_down(){
  lcd.setCursor(0,1);
  lcd.print("Suelto DOWN     ");
}
void apr_down(){
  lcd.setCursor(0,1);
  lcd.print("Apreto DOWN     ");
}
void sue_left(){
  lcd.setCursor(0,1);
  
  lcd.print("Suelto LEFT     ");
}
void apr_left(){
  lcd.setCursor(0,1);
  lcd.print("Apreto LEFT     ");
}
void sue_right(){
  lcd.setCursor(0,1);
  lcd.print("Suelto RIGHT    ");
}
void apr_right(){
  lcd.setCursor(0,1);
  lcd.print("Apreto RIGHT     ");
}
void sue_select(){
  lcd.setCursor(0,1);
  lcd.print("Suelto SELECT   ");
}
void apr_select(){
  lcd.setCursor(0,1);
  lcd.print("Apreto SELECT   ");
}


void setup()
{
  
  fnqueue_init();
  key_up_callback(sue_up,TECLA0);
  key_down_callback(apr_up,TECLA0);
  key_up_callback(sue_down,TECLA1);
  key_down_callback(apr_down,TECLA1);
  key_up_callback(sue_left,TECLA2);
  key_down_callback(apr_left,TECLA2);
  key_up_callback(sue_right,TECLA3);
  key_down_callback(apr_right,TECLA3);
  key_up_callback(sue_select,TECLA4);
  key_down_callback(apr_select,TECLA4);
  
    lcd.begin(numCols,numRows); //Setea las filas y columnas del shield
    analogWrite(10, 1023); //Controla la intensidad backlight
    lcd.setCursor(0, 0);
    lcd.print("Labo 02");
    lcd.setCursor(0, 1);
    lcd.print("Mauro Fonseca");
    delay(1000);
    lcd.setCursor(0, 1);
    lcd.print("A presionar!    ");
    teclado_setup();
}


void loop()
{
  fnqueue_run();
  
}
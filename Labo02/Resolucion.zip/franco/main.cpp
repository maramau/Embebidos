/*
 LCD1602 Keypad Shield 1.0 Test Sketch - LiquidCrystal Library
 
 Este sketch demuestra el uso del LCD1602 Key Shield 1.0.
 Para ello se toman los pulsos de los botones mediante la entrada
 anal�gica AD0 y, mediante la librer�a LiquidCrystal de Arduino 1.0,
 se muestra en el display la tecla pulsada. La librer�a LiquidCrystal
 permite controlar cualquier display LCD compatible con el 
 controlador Hitachi HD44780.
 
 La configuraci�n de la Librer�a se realiza en base al esquem�tico
 del shield.
 
 Este ejemplo est� basado en un ejemplo provisto con la documentaci�n del
 LCD1602 Keypad Shield, el cu�l ha sido adaptado en base a los ejemplos 
 de la librer�a LiquidCrystal de Arduino.
 
 http://www.arduino.cc/en/Tutorial/LiquidCrystal
 http://arduino.cc/en/Reference/LiquidCrystal
 
 
 */
#include <fnqueue.h>
#include <stdbool.h>
#include <stdint.h>
#include "Arduino.h"
// include the library code:
#include <LiquidCrystal.h>
#include <device.h>

// these constants won't change.  But you can change the size of
// your LCD using them:
const uint8_t numRows = 2;
const uint8_t numCols = 16;

// initialize the library with the numbers of the interface pins
LiquidCrystal lcd(8, 9, 4, 5, 6, 7);

void up_keyUp(){
	lcd.setCursor(0,1);
	lcd.print("up keyUp     ");
}

void down_keyUp(){
	lcd.setCursor(0,1);
	lcd.print("down keyUp       ");
}
void up_keyDown(){
	lcd.setCursor(0,1);
	lcd.print("up keyDown       ");
}

void down_keyDown(){
	lcd.setCursor(0,1);
	lcd.print("down keyDown        ");
}
void up_keyLeft(){
	lcd.setCursor(0,1);
	
	lcd.print("up keyLeft         ");
}

void down_keyLeft(){
	lcd.setCursor(0,1);
	lcd.print("down keyLeft           ");
}
void up_keyRight(){
	lcd.setCursor(0,1);
	lcd.print("up keyRight          ");
}

void down_keyRight(){
	lcd.setCursor(0,1);
	lcd.print("down keyRight             ");
}

void up_keySelect(){
	lcd.setCursor(0,1);
	lcd.print("up keySelect              ");
}

void down_keySelect(){
	lcd.setCursor(0,1);
	lcd.print("down keySelect            ");
}

//Key message
char msgs[5][17] = 
{
    " Right Key:  OK ", 
    " Up Key:     OK ", 
    " Down Key:   OK ", 
    " Left Key:   OK ", 
    " Select Key: OK "
};
uint16_t adc_key_val[5] ={30, 300, 360, 535, 760 };
uint8_t NUM_KEYS = 5;
uint16_t adc_key_in;
uint16_t key=-1;
uint16_t oldkey=-1;



void setup() 
{
	teclado_setup();
	fnqueue_init();
	key_up_callback(up_keyUp,TECLA0);
	key_down_callback(down_keyUp,TECLA0);
	key_up_callback(up_keyDown,TECLA1);
	key_down_callback(down_keyDown,TECLA1);
	key_up_callback(up_keyLeft,TECLA2);
	key_down_callback(down_keyLeft,TECLA2);
	key_up_callback(up_keyRight,TECLA3);
	key_down_callback(down_keyRight,TECLA3);
	key_up_callback(up_keySelect,TECLA4);
	key_down_callback(down_keySelect,TECLA4);
	
	// set up the LCD's number of columns and rows: 
    lcd.begin(numCols,numRows);
    analogWrite(10, 1023); //Controla intensidad backlight
    lcd.setCursor(0, 0);
    lcd.print("Key Pad Test");
    lcd.setCursor(0, 1);
    lcd.print("Sist.Emb. 2019");
    delay(2000);
    lcd.setCursor(0, 1);
    lcd.print("Press any key...");
}

void loop()
{
	fnqueue_run();
	
}



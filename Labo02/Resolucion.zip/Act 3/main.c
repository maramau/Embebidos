#include <stdbool.h>
#include <stdint.h>
#include <LiquidCrystal.h>
#include "Arduino.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#include <SoftwareSerial.h>

#include "critical.h"
#include "device.h"
#include "fnqueue.h"
// these constants won't change.  But you can change the size of
// your LCD using them:
const uint8_t numRows = 2;
const uint8_t numCols = 16;
uint8_t modo = 1;    //1: Modo pausa
                     //2: Modo Contador ascendente
                     //3: Modo visor de tiempos
                     //4: Modo aumentacion de dimmer
uint8_t inactivo = 1;//1 si el usuario no esta apretando ningun boton
uint8_t contadorBot = 0;   //Cuenta los segundos desde la ultima apretada/soltada de boton

struct cronometro{
  uint8_t segundos;
  uint8_t minutos;
  uint8_t horas;
};
struct cronometro cron;

uint8_t punteroTiempos = 0;   //Pointer al tiempo guardado
uint8_t cantTiempos = 0;
cronometro listaTiempos[10];     //Lista de tiempos guardados

uint8_t listaBrillos[5] ={51, 102, 153, 204, 255 };
uint8_t punteroBrillo=0;



// initialize the library with the numbers of the interface pins
LiquidCrystal lcd(8, 9, 4, 5, 6, 7);

//***
//Funciones usadas por la interrupcion
//***
  //Actualizo el tiempo de inactividad del teclado
void actContadorBot(){
    //Actualizo el contador del boton
    contadorBot++;
    if(contadorBot>=5)
    {
      if (inactivo && modo!=2)
      {//Si no esta presionando ningun boton
        modo=1;
        iniciarModo();
      }
    }  
}
  //Actualizo el tiempo que corre en el modo MCA
void actCron(){
    cron.segundos++;
    if(cron.segundos>=60){
      cron.segundos=0;
      cron.minutos++;
      if(cron.minutos>=60){
        cron.horas++;
      }
    }
}


//Interrupcion
//Una vez por segundo actualizo los tiempos de inactividd del teclado y el tiempo que pasa
ISR(TIMER1_COMPA_vect)
{
    critical_begin();
    actContadorBot();
    actCron();
    critical_end();
}

void imprimirTiempo(){
     lcd.setCursor(0,1);
     lcd.print("T");
     lcd.print(punteroTiempos);
     lcd.print("  ");
     
     if(listaTiempos[punteroTiempos].horas<9){
      lcd.print("0");
     }
      lcd.print(listaTiempos[punteroTiempos].horas);

     lcd.print(" : ");
     
     if(listaTiempos[punteroTiempos].minutos<9){
      lcd.print("0");
     }
     lcd.print(listaTiempos[punteroTiempos].minutos);

     lcd.print(" : ");
     
     if(listaTiempos[punteroTiempos].segundos<9){
      lcd.print("0");
     }
     lcd.print(listaTiempos[punteroTiempos].segundos);
}

void iniciarModo(){
     lcd.setCursor(0,0);
     switch (modo){
      case 1:
        lcd.println("Modo MP         ");
        TIMSK1 &= (0 << OCIE1A);
      break;
      case 2:
        lcd.println("Modo MCA        ");
        TIMSK1 |= (1 << OCIE1A);
      break;
      case 3:
        lcd.println("Modo MVT        ");
        TIMSK1 |= (1 << OCIE1A);
      break;
      case 4:
        lcd.println("Modo MAD        ");
        TIMSK1 |= (1 << OCIE1A);
      break;
     }
     lcd.setCursor(0,1);
     lcd.println("                ");
}


//*
//Funciones que usara el ISR
//*
void sue_up(){
  switch (modo){
    case 1:
        //Estoy en modo pausa y voy al modo MCA. Empieza a correr el reloj
        modo=2;
        iniciarModo();
        //Enable timer compare interrupt:
        TIMSK1 |= (1 << OCIE1A);
    break;

    case 2:
        //Voy al modo pausa. Inicializo la estructura cronometro y paro el reloj
          //Esto tambien para el reloj de inactividad. Dado que por inactividad se va al modo pausa esto no importa
        cron.segundos=0;
        cron.minutos=0;
        cron.horas=0;
        modo=1;
        iniciarModo();
        //Disable timer compare interrupt:
        TIMSK1 &= (0 << OCIE1A);
    break;
    
    case 3:
        if(punteroTiempos<9){
          
          punteroTiempos++; //Como mucho almaceno 10 tiempos
          
        }
        imprimirTiempo();
    break;
    
    case 4:
        if(punteroBrillo<=4){
          punteroBrillo++;
        }
        analogWrite(10, listaBrillos[punteroBrillo]);
        lcd.setCursor(0,1);
        lcd.print("Brillo:        ");
        lcd.println(punteroBrillo);
    break;
  }
  inactivo = 1;
  contadorBot = 0;
}

void apr_up(){
    switch (modo){
    case 1:
    break;

    case 2:
    break;
    
    case 3:
    break;
    
    case 4:
    break;
  }
  inactivo = 0;
  contadorBot = 0;
}

void sue_down(){
    switch (modo){
    case 1:
        //Estoy en MP, me quedo en MP, guardo el contador y pongo el contador en 0
        lcd.setCursor(0,1);
        lcd.println("Guardo, cont a 0");
        if(cantTiempos<10){
            listaTiempos[cantTiempos].horas = cron.horas;
            listaTiempos[cantTiempos].minutos = cron.minutos;
            listaTiempos[cantTiempos].segundos = cron.segundos;
            cantTiempos++;
        }
        cron.horas = 0;
        cron.minutos = 0;
        cron.segundos = 0;
    break;

    case 2:
        lcd.setCursor(0,1);
        if(cantTiempos<10){
            listaTiempos[cantTiempos].horas = cron.horas;
            listaTiempos[cantTiempos].minutos = cron.minutos;
            listaTiempos[cantTiempos].segundos = cron.segundos;
            cantTiempos++;
            lcd.print("Guardo T:");
            lcd.print(cantTiempos);
            lcd.print("      ");
        }else{
            lcd.print("Espacio lleno   ");
        }

    break;
    
    case 3:
        if(punteroTiempos>0){
          punteroTiempos--; //Como mucho almaceno 10 tiempos
        }
        imprimirTiempo();
    break;
    
    case 4:
        if(punteroBrillo>=1){
          punteroBrillo--;
        }
        analogWrite(10, listaBrillos[punteroBrillo]);
        lcd.setCursor(0,1);
        lcd.print("Brillo:        ");
        lcd.println(punteroBrillo);
    break;
  }
  inactivo = 1;
  contadorBot = 0;
}

void apr_down(){
  switch (modo){
    case 1:
    break;

    case 2:
    break;
    
    case 3:
    break;
    
    case 4:
    break;
  }
   inactivo = 0;
   contadorBot = 0;
}

void sue_left(){
     //lcd.setCursor(0,1);
     //lcd.println("Opcion invalida ");
}

void apr_left(){
     //lcd.setCursor(0,1);
     //lcd.println("Opcion invalida ");
}
void sue_right(){
     //lcd.setCursor(0,1);
     //lcd.println("Opcion invalida ");
}

void apr_right(){
     //lcd.setCursor(0,1);
     //lcd.println("Opcion invalida ");
}

void sue_select(){
     switch (modo){
      case 1:
        if (contadorBot>=3)
        {//presionado por mas de 3 seg
          modo = 4;
          iniciarModo();
        }else{
          modo = 3;
          iniciarModo();
          punteroTiempos=0;
          imprimirTiempo();
        }
      break;

      case 2:
          //Nada por diseño
      break;
      
      case 3:
        modo = 1;
        iniciarModo();
      break;
      
      case 4:
        modo = 1;
        iniciarModo();
      break;
    }
  inactivo = 1;
  contadorBot = 0;
    
}

void apr_select(){
  switch (modo){
    case 1:
        //Estoy en el modo MP, habilito el reloj para saber a donde ir cuando suelte
        TIMSK1 |= (1 << OCIE1A);
        
    break;

    case 2:
        //Nada por diseño
    break;
    
    case 3:
        //Voy a MP cuando suelto
    break;
    
    case 4:
        //Voy a MP cuando suelto
    break;
  }
  inactivo = 0;
  contadorBot = 0;
}


void clock_setup(){
  cli();

  //Habilito el clock en modo CTC para que se interrumpa cada 1 seg
        //El siguiente comando es el responsable de apagar el backlit
  TCCR1A = 0; // set entire TCCR1A register to 0
  TCCR1B = 0; // same for TCCR1B
  
  //Se calculo la cantidad de ciclos que se dan en 1 seg en base a la cuenta
  //(# timer counts + 1) = (target time) / (timer resolution)  
  OCR1A = 15624;
  // turn on CTC mode:
  TCCR1B |= (1 << WGM12);
  // Set CS10 and CS12 bits for 1024 prescaler:
  TCCR1B |= (1 << CS10);
  TCCR1B |= (1 << CS12);
  // enable timer compare interrupt:
  TIMSK1 |= (1 << OCIE1A);

  sei();
}

void setup()
{
  
  fnqueue_init();
  key_up_callback(sue_up,TECLA0);
  key_down_callback(apr_up,TECLA0);
  key_up_callback(sue_down,TECLA1);
  key_down_callback(apr_down,TECLA1);
  key_up_callback(sue_left,TECLA2);
  key_down_callback(apr_left,TECLA2);
  key_up_callback(sue_right,TECLA3);
  key_down_callback(apr_right,TECLA3);
  key_up_callback(sue_select,TECLA4);
  key_down_callback(apr_select,TECLA4);
  clock_setup();
    pinMode(10, OUTPUT);  //Pin del backlight
    lcd.begin(numCols,numRows); //Setea las filas y columnas del shield
    analogWrite(10, 255); //Controla la intensidad backlight
    lcd.setCursor(0, 0);
    lcd.print("Sistemas Emb.   ");
    lcd.setCursor(0, 1);
    lcd.print("2do Cuat. 2020");
    delay(1000);
    lcd.setCursor(0, 0);
    lcd.print("Labo 02        ");
    lcd.setCursor(0, 1);
    lcd.print("Mauro Fonseca    ");
    teclado_setup();
    

    Serial.begin(9600);
    while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
   }
}


void loop()
{
  fnqueue_run();
  
}